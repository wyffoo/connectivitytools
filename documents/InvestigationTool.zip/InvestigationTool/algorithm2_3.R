#Algorithm for total RTS construction cost evaluation between object and SN in locality

#Number of retransmission sites calculation
formula_2_3_1 <- function (input, intermediate = NULL)
{
  req (input)
  
  result =  round ((input$SchoolSpecificData.Length)/input$InitialDataRadio.RetransmissionLength, digits = 0) + 1
  
  return (result)
}

#Number of repeaters by selected technology calculation
formula_2_3_2 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRetransmissionSites <- 0 
  NumberOfRetransmissionSites <- input$Intermediate.NumberOfRetransmissionSites
  
  
  if (!is.null(intermediate))
  {
    NumberOfRetransmissionSites <- as.numeric (intermediate$NumberOfRetransmissionSites)
  }
  
  result =  NumberOfRetransmissionSites - 1
  
  return (result)
}

#Internal RTS devices total cost 
formula_2_3_3 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.RTSDevicesCost*(2*NumberOfRepeaters+input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Antenna feeder devices total cost 
formula_2_3_4 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.AFDCost*(2*NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Main material total cost for RTS pylon construction
formula_2_3_5 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.PylonCost*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Total cost for geodetic work at RTS pylon location
formula_2_3_6 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.GeoPylonCost*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)*input$InitialDataRadio.LaborNormsGeoPylon
  
  return (result)
}

#Total cost for pylon construction of RTS antenna feeder devices
formula_2_3_7 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.PylonConstractionCost*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)*input$InitialDataRadio.LaborNormsPylon
  
  return (result)
}

#Total cost for all antenna feeder devices installation and commissioning for along RTS route
formula_2_3_8 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.CostNormsAFD*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)*input$InitialDataRadio.LaborNormsAFDinst
  
  return (result)
}

#Total cost for internal devices installation and commissioning for RTS
formula_2_3_9 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.CostAFDinst*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)*input$InitialDataRadio.LaborNormsInternalRTS
  
  return (result)
}

#Total cost for design solutions coordination on RTS construction
formula_2_3_10 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.CostDesing*input$InitialDataRadio.LaborNormsDesign*(NumberOfRepeaters + input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Design cost
formula_2_3_11 <- function (input, intermediate = NULL)
{
  req (input)
  
  CostOfAllAFDInstall <- 0 
  CostOfAllAFDInstall <- input$Intermediate.CostOfAllAFDInstall
  
  CostOfAllDevicesInstall <- 0 
  CostOfAllDevicesInstall <- input$Intermediate.CostOfAllDevicesInstall

  CostOfAllPylonsInstall <- 0 
  CostOfAllPylonsInstall <- input$Intermediate.CostOfAllPylonsInstall
  
  if (!is.null(intermediate))
  {
    CostOfAllAFDInstall <- as.numeric (intermediate$CostOfAllAFDInstall)
    CostOfAllDevicesInstall <- as.numeric (intermediate$CostOfAllDevicesInstall)
    CostOfAllPylonsInstall <- as.numeric (intermediate$CostOfAllPylonsInstall)
  }
  
  result =  (CostOfAllAFDInstall + CostOfAllDevicesInstall + CostOfAllPylonsInstall)*0.05
  
  return (result)
}

#RTS construction total cost
formula_2_3_12 <- function (input, intermediate = NULL)
{
  req (input)
  
  CostOfAllAFDInstall <- 0 
  CostOfAllAFDInstall <- input$Intermediate.CostOfAllAFDInstall

  CostOfAllDevicesInstall <- 0 
  CostOfAllDevicesInstall <- input$Intermediate.CostOfAllDevicesInstall

  CostOfAllPylonsInstall <- 0 
  CostOfAllPylonsInstall <- input$Intermediate.CostOfAllPylonsInstall

  CostOfInternalDevices <- 0 
  CostOfInternalDevices <- input$Intermediate.CostOfInternalDevices

  CostOfAFDUnits <- 0 
  CostOfAFDUnits <- input$Intermediate.CostOfAFDUnits

  CostOfPylonsMaterials <- 0 
  CostOfPylonsMaterials <- input$Intermediate.CostOfPylonsMaterials

  CostOfDesign <- 0 
  CostOfDesign <- input$Intermediate.CostOfDesign

  CostOfDesignSolutions <- 0 
  CostOfDesignSolutions <- input$Intermediate.CostOfDesignSolutions
  
  
  if (!is.null(intermediate))
  {
    CostOfAllAFDInstall <- as.numeric (intermediate$CostOfAllAFDInstall)
    CostOfAllDevicesInstall <- as.numeric (intermediate$CostOfAllDevicesInstall)
    CostOfAllPylonsInstall <- as.numeric (intermediate$CostOfAllPylonsInstall)
    CostOfInternalDevices <- as.numeric (intermediate$CostOfInternalDevices)
    CostOfAFDUnits <- as.numeric (intermediate$CostOfAFDUnits)
    CostOfPylonsMaterials <- as.numeric (intermediate$CostOfPylonsMaterials)
    CostOfDesign <- as.numeric (intermediate$CostOfDesign)
    CostOfDesignSolutions <- as.numeric (intermediate$CostOfDesignSolutions)
  }
  
  result =  CostOfAllAFDInstall+CostOfAllDevicesInstall+
    CostOfAllPylonsInstall+ CostOfInternalDevices+
    CostOfAFDUnits+CostOfPylonsMaterials+
    CostOfDesign+CostOfDesignSolutions
  
  return (result)
}

#Total cost of equipment and materials for the construction of the RTS
formula_2_3_13 <- function (input, intermediate = NULL)
{
  req (input)
  
  CostOfPylonsMaterials <- 0 
  CostOfPylonsMaterials <- input$Intermediate.CostOfPylonsMaterials

  CostOfInternalDevices <- 0 
  CostOfInternalDevices <- input$Intermediate.CostOfInternalDevices

  CostOfAFDUnits <- 0 
  CostOfAFDUnits <- input$Intermediate.CostOfAFDUnits
  

  if (!is.null(intermediate))
  {
    CostOfPylonsMaterials <- as.numeric (intermediate$CostOfPylonsMaterials)
    CostOfInternalDevices <- as.numeric (intermediate$CostOfInternalDevices)
    CostOfAFDUnits <- as.numeric (intermediate$CostOfAFDUnits)
  }
  
  result =  CostOfPylonsMaterials + CostOfInternalDevices  +  CostOfAFDUnits
  
  return (result)
}


algorithm2_3_impl <- function(input, intermediate = NULL)
{

  #Number of retransmission sites calculation
  NumberOfRetransmissionSites =  formula_2_3_1 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Number of retransmission sites calculation, units", NumberOfRetransmissionSites, sep = ": "))  
  
  #Number of repeaters by selected technology calculation
  intermediate2 <- list (NumberOfRetransmissionSites = 0, NumberOfRepeaters = 0)
  intermediate2$NumberOfRetransmissionSites <- NumberOfRetransmissionSites
  
  NumberOfRepeaters =  formula_2_3_2 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Number of repeaters by selected technology calculation, units", NumberOfRepeaters, sep = ": "))  
  
  intermediate2$NumberOfRepeaters <- NumberOfRepeaters
  
  #Internal RTS devices total cost 
  CostOfAllDevicesInstall =  formula_2_3_3 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Internal RTS devices total cost, currency units", CostOfAllDevicesInstall, sep = ": "))  
  
  #Antenna feeder devices total cost 
  CostOfAFDUnits =  formula_2_3_4 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Antenna feeder devices total cost , currency units", CostOfAFDUnits, sep = ": "))  
  
  #Main material total cost for RTS pylon construction
  CostOfPylonsMaterials =  formula_2_3_5 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Main material total cost for RTS pylon construction, currency units", CostOfPylonsMaterials, sep = ": "))  
  
  #Total cost for geodetic work at RTS pylon location
  CostOfGeodeticWork =  formula_2_3_6 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for geodetic work at RTS pylon location, currency units", CostOfGeodeticWork, sep = ": "))  
  
  #Total cost for pylon construction of RTS antenna feeder devices
  CostOfAllPylonsInstall =  formula_2_3_7 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for pylon construction of RTS antenna feeder devices, currency units", CostOfAllPylonsInstall, sep = ": "))  
  
  #Total cost for all antenna feeder devices installation and commissioning for along RTS route
  CostOfAllAFDInstall =  formula_2_3_8 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for all antenna feeder devices installation and commissioning for along RTS route, currency units", CostOfAllAFDInstall, sep = ": "))  
  
  #Total cost for internal devices installation and commissioning for RTS
  CostOfInternalDevices =  formula_2_3_9 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for internal devices installation and commissioning for RTS, currency units", CostOfInternalDevices, sep = ": "))  
  
  #Total cost for design solutions coordination on RTS construction
  CostOfDesignSolutions =  formula_2_3_10 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for design solutions coordination on RTS construction, currency units", CostOfDesignSolutions, sep = ": "))  
  
  intermediate3 <- list (CostOfAllAFDInstall = 0.0,
                         CostOfAllDevicesInstall  = 0.0,
                         CostOfAllPylonsInstall  = 0.0,
                         CostOfGeodeticWork  = 0.0,
                         CostOfInternalDevices = 0.0,
                           CostOfAFDUnits = 0.0,
                          CostOfPylonsMaterials = 0.0,
                           CostOfDesign = 0.0,
                         CostOfDesignSolutions = 0.0
                         )
  
  intermediate3$CostOfAllAFDInstall <- CostOfAllAFDInstall
  intermediate3$CostOfAllDevicesInstall <- CostOfAllDevicesInstall
  intermediate3$CostOfAllPylonsInstall <- CostOfAllPylonsInstall
  intermediate3$CostOfGeodeticWork <- CostOfGeodeticWork
  
    
  #Design cost
  CostOfDesign =  formula_2_3_11 (input, intermediate3)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Design cost, currency units", CostOfDesign, sep = ": "))  
  
  intermediate3$CostOfInternalDevices <- CostOfInternalDevices
  intermediate3$CostOfAFDUnits <- CostOfAFDUnits
  intermediate3$CostOfPylonsMaterials <- CostOfPylonsMaterials
  intermediate3$CostOfDesign <- CostOfDesign
  intermediate3$CostOfDesignSolutions <- CostOfDesignSolutions
  
    
  #RTS construction total cost
  
  result <- matrix (nrow = 3, ncol = 2)
  result [1,1] = "RTS construction total cost, currency units"
  result [1,2] = formula_2_3_12 (input, intermediate3)

  result [2,1] = "Number of repeaters by selected technology calculation, units"
  result [2,2] = NumberOfRepeaters
  
  result [3,1] = "Total cost of equipment and materials for the construction of the RTS, currency units"
  result [3,2] = formula_2_3_13 (input, intermediate3)
    
  return (result)
}
  


algorithm2_3 <- function(input, output)
{
  req (input)
  req (input$formula)
  req (output)
  
  switch (input$formula, 
          ALL = {
            
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataRadio.RetransmissionLength)
            req (input$InitialDataRadio.RTSDevicesCost)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.AFDCost)
            req (input$InitialDataRadio.PylonCost)
            req (input$InitialDataRadio.GeoPylonCost)
            req (input$InitialDataRadio.LaborNormsGeoPylon)
            req (input$InitialDataRadio.PylonConstractionCost)
            req (input$InitialDataRadio.LaborNormsPylon)
            req (input$InitialDataRadio.CostNormsAFD)
            req (input$InitialDataRadio.LaborNormsAFDinst)
            req (input$InitialDataRadio.CostAFDinst)
            req (input$InitialDataRadio.LaborNormsInternalRTS)
            req (input$InitialDataRadio.CostDesing)
            req (input$InitialDataRadio.LaborNormsDesign)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- algorithm2_3_impl (input)
            
            output$c_names <- NULL            
            
            output$data <- renderTable(result, colnames=FALSE) 
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          FORMULA_2_3_1 = {#Number of retransmission sites calculation
            
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataRadio.RetransmissionLength)
            
            result <- formula_2_3_1 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_2 = {#Number of repeaters by selected technology calculation
            
            req (input$Intermediate.NumberOfRetransmissionSites)
            
            result <- formula_2_3_2 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_3 = {#Internal RTS devices total cost 
            
            req (input$InitialDataRadio.RTSDevicesCost)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            result <- formula_2_3_3 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_4 = {#Antenna feeder devices total cost 
            req (input$InitialDataRadio.AFDCost)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            result <- formula_2_3_4 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_5 = {#Main material total cost for RTS pylon construction
            req (input$InitialDataRadio.PylonCost)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            result <- formula_2_3_5 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_6 = {#Total cost for geodetic work at RTS pylon location
            req (input$InitialDataRadio.GeoPylonCost)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.LaborNormsGeoPylon)
            
            result <- formula_2_3_6 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_7 = {#Total cost for pylon construction of RTS antenna feeder devices
            req (input$InitialDataRadio.PylonConstractionCost)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.LaborNormsPylon)
            
            result <- formula_2_3_7 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_8 = {#Total cost for all antenna feeder devices installation and commissioning for along RTS route
            req (input$InitialDataRadio.CostNormsAFD)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.LaborNormsAFDinst)
            
            result <- formula_2_3_8 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_9 = {#Total cost for internal devices installation and commissioning for RTS
            req (input$InitialDataRadio.CostAFDinst)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.LaborNormsInternalRTS)
            
            result <- formula_2_3_9 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_10 = {#Total cost for design solutions coordination on RTS construction
            req (input$InitialDataRadio.CostDesing)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.LaborNormsDesign)
            
            result <- formula_2_3_10 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_11 = {#Design cost
            req (input$Intermediate.CostOfAllAFDInstall)
            req (input$Intermediate.CostOfAllDevicesInstall)
            req (input$Intermediate.CostOfAllPylonsInstall)
            
            result <- formula_2_3_11 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_12 = {#RTS construction total cost
            req (input$Intermediate.CostOfAllAFDInstall)
            req (input$Intermediate.CostOfAllDevicesInstall)
            req (input$Intermediate.CostOfAllPylonsInstall)
            req (input$Intermediate.CostOfInternalDevices)
            req (input$Intermediate.CostOfAFDUnits)
            req (input$Intermediate.CostOfPylonsMaterials)
            req (input$Intermediate.CostOfDesign)
            req (input$Intermediate.CostOfDesignSolutions)
            
            result <- formula_2_3_12 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_3_13 = {#Total cost of equipment and materials for the construction of the RTS
            req (input$Intermediate.CostOfPylonsMaterials)
            req (input$Intermediate.CostOfInternalDevices)
            req (input$Intermediate.CostOfAFDUnits)
            
            result <- formula_2_3_13 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
         stop ("No!")
          
  )
}
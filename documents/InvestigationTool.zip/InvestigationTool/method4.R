#Topology accounting methodology for a large number of objects

source ("algorithm4_1.R")
source ("algorithm4_2.R")

method4_impl <- function(input, intermediate = NULL)
{
  #Geodesic distance calculation between investigated objects (localities) in estimated broadband network
  
  res0 <- algorithm4_1_impl (input)
  
  result <- 0 

  return (result)
}

method4_inv_impl <- function(input, intermediate = NULL)
{
  
  
  result <- 0 
  
  return (result)
}

method4 <- function(input, output)
{
  switch (input$algorithm, 
          ALL = {
            
            req (input$GeneralVariables.CostOfSTCEq)
            

            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            
            result <- method4_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE) 
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
            
          },
          ALGORITHM4_1 = {#Geodesic distance calculation between investigated objects (localities) in estimated broadband network
            algorithm4_1 (input, output)
          },
          ALGORITHM4_2 = {#NPV matrix calculations
            algorithm4_2 (input, output)
          },
          stop ("No!")
  )
}


method4_inv <- function(input, output)
{
  req (input)
  req (input$algorithm)
  req (output)
  
}
#Algorithm for overall FOCL maintenance cost evaluation

#FOCL maintenance cost along the route
formula_2_2_1 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
  }
  
  result =  FOCLLenghtTotal*input$InitialDataFOCL.AnnualLaborNormFOCLm*input$InitialDataFOCL.CostNormFOCLm
  
  return (result)
}

#Cable duct maintenance cost
formula_2_2_2 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLSectionLengthCD <- 0 
  FOCLSectionLengthCD <- input$Intermediate.FOCLSectionLengthCD
  
  
  if (!is.null(intermediate))
  {
    FOCLSectionLengthCD <- as.numeric (intermediate$FOCLSectionLengthCD)
  }
  
  result =  FOCLSectionLengthCD*input$InitialDataFOCL.AnnualLaborNormCDm*input$InitialDataFOCL.CostNormCDm
  
  return (result)
}

#Building entrance facilities maintenance cost
formula_2_2_3 <- function (input, intermediate = NULL)
{
  req (input)
  
  result =  input$InitialDataFOCL.NumberBEF*input$InitialDataFOCL.AnnualLaborNormBEFm*input$InitialDataFOCL.CostNormBEFm
  
  return (result)
}

#ODF maintenance cost
formula_2_2_4 <- function (input, intermediate = NULL)
{
  req (input)
  
  result =  input$InitialDataFOCL.NumberODF*input$InitialDataFOCL.AnnualLaborNormODFm*input$InitialDataFOCL.CostNormODFm
  
  return (result)
}

#Total cost for FOCL maintenance for the entire period of operation
formula_2_2_5 <- function (input, intermediate = NULL)
{
  req (input)
  
  AnnualCostFOCLmaintenance <- 0 
  AnnualCostFOCLmaintenance <- input$Intermediate.AnnualCostFOCLmaintenance
  
  AnnualCostCDmaintenance <- 0 
  AnnualCostCDmaintenance <- input$Intermediate.AnnualCostCDmaintenance
  
  
  AnnualCostBEFmaintenance <- 0 
  AnnualCostBEFmaintenance <- input$Intermediate.AnnualCostBEFmaintenance
  
  AnnualCostODFmaintenance <- 0 
  AnnualCostODFmaintenance <- input$Intermediate.AnnualCostODFmaintenance
  
    
  if (!is.null(intermediate))
  {
    AnnualCostFOCLmaintenance <- as.numeric (intermediate$AnnualCostFOCLmaintenance)
    
    AnnualCostCDmaintenance <- as.numeric (intermediate$AnnualCostCDmaintenance)
    
    AnnualCostBEFmaintenance <- as.numeric (intermediate$AnnualCostBEFmaintenance)
    
    AnnualCostODFmaintenance <- as.numeric (intermediate$AnnualCostODFmaintenance)
  }
  
  result =  AnnualCostFOCLmaintenance + AnnualCostCDmaintenance +
    AnnualCostBEFmaintenance + AnnualCostODFmaintenance
  
  return (result)
}

algorithm2_2_impl <- function(input, intermediate = NULL)
{

  #FOCL maintenance cost along the route
  AnnualCostFOCLmaintenance =  formula_2_2_1 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("FOCL maintenance cost along the route, currency units/year", AnnualCostFOCLmaintenance, sep = ": "))  
  
  #Cable duct maintenance cost
  AnnualCostCDmaintenance =  formula_2_2_2 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Cable duct maintenance cost, currency units/year", AnnualCostCDmaintenance, sep = ": "))  
  
  #Building entrance facilities maintenance cost
  AnnualCostBEFmaintenance =  formula_2_2_3 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Building entrance facilities maintenance cost, currency units/year", AnnualCostBEFmaintenance, sep = ": "))  
  
  #ODF maintenance cost
  AnnualCostODFmaintenance =  formula_2_2_4 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("ODF maintenance cost, currency units/year", AnnualCostODFmaintenance, sep = ": "))  
  
  #Total cost for FOCL maintenance for the entire period of operation            
  
  intermediate2 <- list (AnnualCostFOCLmaintenance = 0.0,
                         AnnualCostCDmaintenance = 0.0, 
                         AnnualCostBEFmaintenance = 0, 
                         AnnualCostODFmaintenance = 0)
  intermediate2$AnnualCostFOCLmaintenance <- AnnualCostFOCLmaintenance
  intermediate2$AnnualCostCDmaintenance <- AnnualCostCDmaintenance
  intermediate2$AnnualCostBEFmaintenance <- AnnualCostBEFmaintenance
  intermediate2$AnnualCostODFmaintenance <- AnnualCostODFmaintenance
  
  result <- matrix (nrow = 1, ncol = 2)
  result [1,1] = "Anual Cost for FOCL maintenance, currency units/year"
  result [1,2] = formula_2_2_5 (input, intermediate2)
  
  return (result)
}

algorithm2_2 <- function(input, output)
{
  req (input)
  req (input$formula)
  req (output)
  
  switch (input$formula, 
          ALL = {
            
            req (input$Intermediate.FOCLLenghtTotal)
            req (input$InitialDataFOCL.AnnualLaborNormFOCLm)
            req (input$InitialDataFOCL.CostNormFOCLm)
            req (input$Intermediate.FOCLSectionLengthCD)
            req (input$InitialDataFOCL.AnnualLaborNormCDm)
            req (input$InitialDataFOCL.CostNormCDm)
            req (input$InitialDataFOCL.NumberBEF)
            req (input$InitialDataFOCL.AnnualLaborNormBEFm)
            req (input$InitialDataFOCL.CostNormBEFm)
            req (input$InitialDataFOCL.NumberODF)
            req (input$InitialDataFOCL.AnnualLaborNormODFm)
            req (input$InitialDataFOCL.CostNormODFm)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- algorithm2_2_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE) 
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          FORMULA_2_2_1 = {#FOCL maintenance cost along the route
            
            req (input$Intermediate.FOCLLenghtTotal)
            req (input$InitialDataFOCL.AnnualLaborNormFOCLm)
            req (input$InitialDataFOCL.CostNormFOCLm)
            
            result <- formula_2_2_1 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_2_2 = {#Cable duct maintenance cost
            
            req (input$Intermediate.FOCLSectionLengthCD)
            req (input$InitialDataFOCL.AnnualLaborNormCDm)
            req (input$InitialDataFOCL.CostNormCDm)
            
            result <- formula_2_2_2 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_2_3 = {#Building entrance facilities maintenance cost
            
            req (input$InitialDataFOCL.NumberBEF)
            req (input$InitialDataFOCL.AnnualLaborNormBEFm)
            req (input$InitialDataFOCL.CostNormBEFm)
            
            result <- formula_2_2_3 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_2_4 = {#ODF maintenance cost
            
            req (input$InitialDataFOCL.NumberODF)
            req (input$InitialDataFOCL.AnnualLaborNormODFm)
            req (input$InitialDataFOCL.CostNormODFm)
            
            result <- formula_2_2_4 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_2_5 = {#Total cost for FOCL maintenance for the entire period of operation
            
            req (input$Intermediate.AnnualCostFOCLmaintenance)
            req (input$Intermediate.AnnualCostCDmaintenance)
            req (input$Intermediate.AnnualCostBEFmaintenance)
            req (input$Intermediate.AnnualCostODFmaintenance)
            
            result <- formula_2_2_5 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          stop ("No!")
          
  )
}
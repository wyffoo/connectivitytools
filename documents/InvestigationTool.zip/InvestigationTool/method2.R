source ("algorithm2_0.R")
source ("algorithm2_1.R")
source ("algorithm2_2.R")
source ("algorithm2_3.R")
source ("algorithm2_4.R")
source ("algorithm2_5.R")
source ("algorithm2_6.R")
source ("algorithm2_7.R")

method2_impl <- function(input, intermediate = NULL)
{
  #Algorithm for necessary network channel capacity calculation
  
  result <- algorithm2_0_impl (input)
  RequiredCapacity =  as.numeric (result[1,2])
    
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Necessary (sufficient) network channel capacity, Mbit/s", RequiredCapacity, sep = ": "))                            
  
  
  #Algorithm for overall FOCL construction cost evaluation
  
  result2 =  algorithm2_1_impl (input)
  
  #Overall length of the FOCL construction site
  FOCLLenghtTotal = as.numeric (result2 [2,2])

  FOCLSectionLengthCD =   as.numeric (result2 [3,2])

  #Overall cost of FOCL installation  
  TotalCAPEXFOCL =  as.numeric (result2 [1,2])
  
  #Сost of equipment and materials for the construction of fiber optic lines
  CostOfEqAndMatFOCL =  as.numeric (result2 [4,2])
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost of FOCL installation, currency units", TotalCAPEXFOCL, sep = ": "))  
  
  result <- matrix (nrow = 9, ncol = 2)
  result [1,1] = "Overall cost of FOCL installation, currency units"
  result [1,2] = TotalCAPEXFOCL
  
  #Algorithm for overall FOCL maintenance cost evaluation
  
  intermediate2 <- list (FOCLLenghtTotal = 0.0, FOCLSectionLengthCD = 0.0)
  intermediate2$FOCLLenghtTotal <- FOCLLenghtTotal 
  intermediate2$FOCLSectionLengthCD <- FOCLSectionLengthCD
  
  result3 =  algorithm2_2_impl (input, intermediate2)
  
  #Total cost for FOCL maintenance for the entire period of operation            
  TotalOPEXFOCL =  as.numeric (result3 [1,2])
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for FOCL maintenance for the entire period of operation, currency units/year", TotalOPEXFOCL, sep = ": "))              
  
  result [2,1] = "Annual cost for FOCL maintenance, currency units/year"
  result [2,2] = TotalOPEXFOCL
  
  #Algorithm for total RTS construction cost evaluation between object and SN in locality
  result4 =  algorithm2_3_impl (input, intermediate)

  TotalCAPEXRTS <-   as.numeric (result4 [1,2])
  
  NumberOfRepeaters <-   as.numeric (result4 [2,2])
  
  #Total cost of equipment and materials for the construction of the RTS
  CostOfEqAndMatRTS <-   as.numeric (result4 [3,2])
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("RTS construction total cost, currency units", TotalCAPEXRTS, sep = ": "))  
  
  result [3,1] = "RTS construction total cost, currency units"
  result [3,2] = TotalCAPEXRTS
  
  
  #Algorithm for total RTS maintenance cost evaluation between object and SN in locality
  
  intermediate3 <- list (NumberOfRepeaters = 0)
  intermediate3$NumberOfRepeaters <- NumberOfRepeaters
  result5 =  algorithm2_4_impl (input, intermediate3)
  
  TotalOPEXRTS = as.numeric (result5 [1,2])
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost of RTS maintenance, currency units/year", TotalOPEXRTS, sep = ": "))            
  
  result [4,1] = "Annual cost of RTS maintenance, currency units/year"
  result [4,2] = TotalOPEXRTS
  
  
  #Algorithm for determining the total cost of the installation and configuration of the satellite communication channel 
  
  intermediate4 <- list (NumberVSATsets = 0, RequiredCapacity = 0.0)
  intermediate4$RequiredCapacity  <- RequiredCapacity
  
  result6 =  algorithm2_5_impl (input, intermediate4)
  
  # Required number of VSAT sets
  
  NumberVSATsets = as.numeric (result6 [2,2])
  
  TotalCAPEXSetellite =  as.numeric (result6 [1,2])
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost of establishing a satellite communication channel, currency units", TotalCAPEXSetellite, sep = ": "))  
  
  #Total cost of VSAT equipment and installation materials
  CostOfVSATEqAndMat =  as.numeric (result6 [3,2])
  
  result [5,1] = "Total cost of establishing a satellite communication channel, currency units"
  result [5,2] = TotalCAPEXSetellite
  
  
  #Algorithm for determining the total cost of the maintenance of the satellite communication channel 
  
  
  intermediate4$NumberVSATsets <- NumberVSATsets
  
  
  
  result7 =  algorithm2_6_impl (input, intermediate4)
  
  
  TotalOPEXSatellite =  as.numeric (result7 [1,2])
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Annual cost of maintenance of the satellite channel, currency units/year", TotalOPEXSatellite, sep = ": "))              
  
  result [6,1] = "Annual cost of maintenance of the satellite channel, currency units/year"
  result [6,2] = TotalOPEXSatellite
  
  #NPV - FOCL
  intermediate5 <- list (NetIncome = 0.0, TotalInvest = 0.0, CostOfOperation = 0.0, CostOfEquipmentAndMaterials = 0.0)
  TotalInvest <- TotalCAPEXFOCL
  CostOfOperation  <- TotalOPEXFOCL
  CostOfEquipmentAndMaterials  <- CostOfEqAndMatFOCL
  intermediate5$TotalInvest <- TotalInvest
  intermediate5$CostOfOperation <- CostOfOperation
  intermediate5$CostOfEquipmentAndMaterials <- CostOfEquipmentAndMaterials
  
  npv_focl <- algorithm2_7_impl (input, intermediate5)

  result [7,1] = "FOCL - Net Present Value, currency units"
  result [7,2] = as.numeric(npv_focl[1,2])
  
  #NPV - Microwave 
  TotalInvest <- TotalCAPEXRTS
  CostOfOperation  <- TotalOPEXRTS
  CostOfEquipmentAndMaterials  <- CostOfEqAndMatRTS
  
  intermediate5$TotalInvest <- TotalInvest
  intermediate5$CostOfOperation <- CostOfOperation
  intermediate5$CostOfEquipmentAndMaterials <- CostOfEquipmentAndMaterials
  
  npv_microwave <- algorithm2_7_impl (input, intermediate5)
  
  result [8,1] = "RTS - Net Present Value, currency units"
  result [8,2] = as.numeric(npv_microwave[1,2])
  
  #NPV - Satellite 
  TotalInvest <- TotalCAPEXSetellite
  CostOfOperation  <- TotalOPEXSatellite
  CostOfEquipmentAndMaterials  <- CostOfVSATEqAndMat
  
  intermediate5$NetIncome <- 0
  intermediate5$TotalInvest <- TotalInvest
  intermediate5$CostOfOperation <- CostOfOperation
  intermediate5$CostOfEquipmentAndMaterials <- CostOfEquipmentAndMaterials
  
  npv_satellite <- algorithm2_7_impl (input, intermediate5)
  result [9,1] = "Satellite - Net Present Value, currency units"
  result [9,2] = as.numeric(npv_satellite[1,2])
  
  
  return (result)
}

method2_inv_impl <- function(input, intermediate = NULL)
{
  
  
  L <- reactiveValuesToList (input)
  
  
  l_len <- length(L)
  
  result <- matrix (nrow = (l_len-5), ncol = 5)
  curindex <- 1
  
  for (i in 1:l_len)
  {
    elem <- L[i]
    
    e_name <- names (elem [1])
    
    if ((e_name != "calculate") &
        (e_name != "investigate") & 
        (e_name != "formula") & 
        (e_name != "method") &
        (e_name != "algorithm") & 
        (e_name != "investigate") )
    {
      result1 <- method2_impl (L)
      
      val <- as.numeric (elem [[1]])
      
      val2 <- val*2
      elem [[1]] <- val2
      
      L[i] <- elem
      
      result2 <- method2_impl (L)
      
      
      
      val3 <- val*4
      elem [[1]] <- val3
      
      L[i] <- elem
      
      result3 <- method2_impl (L)
      
      
      val4 <- val/2
      elem [[1]] <- val4
      
      L[i] <- elem
      
      result4 <- method2_impl (L)
      
      val5 <- val/4
      elem [[1]] <- val5
      
      L[i] <- elem
      
      result5 <- method2_impl (L)
      
      elem [[1]] <- val
      
      L[i] <- elem
      
      base1 <- (as.numeric (result1[7,2])  +  as.numeric (result1[8,2]) + as.numeric (result1[9,2]))/3
      base2 <- (as.numeric (result2[7,2])  +  as.numeric (result2[8,2]) + as.numeric (result2[9,2]))/3
      base3 <- (as.numeric (result3[7,2])  +  as.numeric (result3[8,2]) + as.numeric (result3[9,2]))/3
      base4 <- (as.numeric (result4[7,2])  +  as.numeric (result4[8,2]) + as.numeric (result4[9,2]))/3
      base5 <- (as.numeric (result5[7,2])  +  as.numeric (result5[8,2]) + as.numeric (result5[9,2]))/3
      
      dif <- round (base2 /base1 , 2)
      
      dif2 <- round (base3 /base1, 2)
      
      dif3 <- round (base4 /base1, 2)
      
      dif4 <- round (base5 /base1, 2)
      
      result [curindex, 1] <- e_name
      result [curindex, 2] <- dif
      result [curindex, 3] <- dif2
      result [curindex, 4] <- dif3
      result [curindex, 5] <- dif4
      
      curindex <- curindex + 1
      
    }
    
  }
  
  
  ndx = order(result [,2], decreasing = T)
  
  
  result2 = result [ndx,]
  
  
  N <- (l_len-5)
  
  
  # for (i in 1:N)
  # {
  #   
  #   name <- result2 [i,1]
  #   
  #   descr <- getdescriptionbyname (name)
  #   
  #   result2 [i,1] <- descr
  # }
  
  nm <- c ("Parameter", "Mean (NPV (Parameter*2)) / Mean (NPV (Parameter))", "Mean (NPV (Parameter*4)) / Mean (NPV (Parameter))", "Mean (NPV (Parameter/2)) / Mean (NPV (Parameter))" , "NPV (Parameter/4) / NPV (Parameter)") 
  
  colnames (result2) <- nm
  
  
  return (result2)
}



method2 <- function(input, output)
{

  switch (input$algorithm, 
          ALL = {
            
            req (input$Files.Traffic)
            
            req (input$InitialDataTraffic.InformationVolume)
            req (input$InitialDataTraffic.BitrateOfService)
            req (input$InitialDataTraffic.IntensivityPerUser)
            req (input$InitialDataTraffic.NumberOfSubscribers)
            req (input$InitialDataTraffic.LevelOfQuality)
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataFOCL.LaborCostNormGeo)
            req (input$InitialDataFOCL.CostNormGeo)
            req (input$InitialDataFOCL.CostNormFOCLinst)
            req (input$InitialDataFOCL.LaborCostNormHDD)
            req (input$InitialDataFOCL.CostNormHDD)
            
            req (input$InitialDataFOCL.LaborCostNormCDC)
            req (input$InitialDataFOCL.CostNormCDC)
            req (input$InitialDataFOCL.CostNormMaterialsCD)
            
            req (input$InitialDataFOCL.LaborCostNormLC)
            req (input$InitialDataFOCL.CostNormLC)
            req (input$InitialDataFOCL.CostNormMaterialsCMh)
            req (input$InitialDataFOCL.LaborCostNormCMh)
            req (input$InitialDataFOCL.CostNormCMh)
            req (input$InitialDataFOCL.CostNormCC1km)

            req (input$SchoolSpecificData.RequiredBandwidth)
            req (input$InitialDataFOCL.LaborCostNormCCI)
            req (input$InitialDataFOCL.CostNormCCI)
            req (input$InitialDataFOCL.LaborCostNormST)
            req (input$InitialDataFOCL.CostNormST)
            req (input$InitialDataFOCL.LaborCostNormTS)
            req (input$InitialDataFOCL.CostNormTS)
            req (input$InitialDataFOCL.LaborCostNormSC)
            req (input$InitialDataFOCL.CostNormSC)
            req (input$InitialDataFOCL.AnnualLaborNormFOCLm)
            req (input$InitialDataFOCL.CostNormFOCLm)
            req (input$InitialDataFOCL.AnnualLaborNormCDm)

            req (input$InitialDataFOCL.CostNormCDm)
            req (input$InitialDataFOCL.NumberBEF)
            req (input$InitialDataFOCL.AnnualLaborNormBEFm)
            req (input$InitialDataFOCL.CostNormBEFm)
            req (input$InitialDataFOCL.NumberODF)
            req (input$InitialDataFOCL.AnnualLaborNormODFm)
            req (input$InitialDataFOCL.CostNormODFm)
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataRadio.RetransmissionLength)
            req (input$InitialDataRadio.RTSDevicesCost)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.AFDCost)
            req (input$InitialDataRadio.PylonCost)
            req (input$InitialDataRadio.GeoPylonCost)
            req (input$InitialDataRadio.LaborNormsGeoPylon)
            req (input$InitialDataRadio.PylonConstractionCost)
            req (input$InitialDataRadio.LaborNormsPylon)
            req (input$InitialDataRadio.CostNormsAFD)
            req (input$InitialDataRadio.LaborNormsAFDinst)
            req (input$InitialDataRadio.CostAFDinst)
            req (input$InitialDataRadio.LaborNormsInternalRTS)
            req (input$InitialDataRadio.CostDesing)
            req (input$InitialDataRadio.LaborNormsDesign)
            req (input$InitialDataRadio.AnnualLaborPylon)
            req (input$InitialDataRadio.CostLaborPylonm)
            req (input$InitialDataRadio.AnnualLaborAFD)

            req (input$InitialDataRadio.CostLaborAFDm)
            req (input$InitialDataRadio.AnnualLaborRTS)
            req (input$InitialDataRadio.CostLaborRTSm)
            
            #req (input$InitialDataSatelite.RequiredCapacity)
            req (input$InitialDataSatelite.ChannelCapacity)
            req (input$InitialDataSatelite.CostOfOneVSAT)
            
            req (input$InitialDataSatelite.CostOfOneVSATmat)
            req (input$InitialDataSatelite.CostOfInstallVSAT)
            req (input$InitialDataSatelite.LaborOfInstallVSAT)
            
            req (input$InitialDataSatelite.AnnualLaborOfServiceVSAT)
            req (input$InitialDataSatelite.CostOfServiceVSAT)
            
            req (input$InitialDataSatelite.AnnualRentBand)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- method2_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE) 
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
                        
          },
          ALGORITHM2_0 = {#Algorithm for necessary network channel capacity calculation
            algorithm2_0 (input, output)
          },
          ALGORITHM2_1 = {#Algorithm for overall FOCL construction cost evaluation
            algorithm2_1 (input, output)
          },
          ALGORITHM2_2 = {#Algorithm for overall FOCL maintenance cost evaluation
            algorithm2_2 (input, output)
          },
          ALGORITHM2_3 = {#Algorithm for total RTS construction cost evaluation between object and SN in locality
            algorithm2_3 (input, output)
          },
          ALGORITHM2_4 = {#Algorithm for total RTS maintenance cost evaluation between object and SN in locality
            algorithm2_4 (input, output)
          },
          ALGORITHM2_5 = {#Algorithm for determining the total cost of the installation and configuration of the satellite communication channel 
            algorithm2_5 (input, output)
          },
          ALGORITHM2_6 = {#Algorithm for determining the total cost of the maintenance of the satellite communication channel 
            algorithm2_6 (input, output)
          },
          ALGORITHM2_7 = {#Algorithm for caclulating NPV
            algorithm2_7 (input, output)
          },
          stop ("No!")
  )
}

method2_inv <- function(input, output)
{
  req (input)
  req (input$algorithm)
  req (output)
  
  switch (input$algorithm, 
          ALL = {
            

            result <- method2_inv_impl (input)
            
            output$c_names <- NULL
            
            output$data <- renderTable(result, colnames=TRUE)
            
             output$log <- NULL
            
            #output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          ALGORITHM2_0 = {#
            
          },
          stop ("No!")
  )
}

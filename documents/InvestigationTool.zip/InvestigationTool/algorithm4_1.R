library(geosphere)

#library(gmapsdistance)

#Geodesic distance calculation between investigated objects (localities) in estimated broadband network


#Geodesic distance between two objects, meters
formula_4_1_1 <- function (input, intermediate = NULL)
{
  req (input)

  result <- distm (c(as.numeric (input$Coordinates.LonFirst), as.numeric (input$Coordinates.LatFirst)),c(as.numeric (input$Coordinates.LonSecond), as.numeric (input$Coordinates.LatSecond)),fun=distHaversine)
  
  return (result)
}

#Distance connectivity matrix between investigated objects (localities) in estimated broadband network
formula_4_1_2 <- function (input, intermediate = NULL)
{
  req (input)
  
  objects <- vroom::vroom(input$Files.ListOfObjects, altrep = FALSE)
  
  req (objects)
  
  numberofobj <- nrow(objects)

  result <- matrix (nrow = numberofobj, ncol = numberofobj)
  
  
  for (i in 1: (numberofobj-1))
  {
    for (j in (i+1):numberofobj)
    {
      lon1 <- objects [i,2]
      lat1 <- objects [i,3]

      lon2 <- objects [j,2]
      lat2 <- objects [j,3]
      
      distancem <- distm (c(as.numeric (lon1), as.numeric (lat1)),c(as.numeric (lon2), as.numeric (lat2)),fun=distHaversine)
      distancekm <- as.numeric (distancem/1000)
      
      result [i,j] <- distancekm
      result [j,i] <- distancekm
      
    }
    result [i,i] <- 0
  }
  
  result [numberofobj,numberofobj] <- 0
  

  return (result)
}




algorithm4_1_impl <- function(input, intermediate = NULL)
{
  
  # Geodesic distance between two objects, meters
  
  DistanceBetweenTwoObjects =  formula_4_1_1 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Geodesic distance between two objects, meters", DistanceBetweenTwoObjects, sep = ": "))  

  
  result <- matrix (nrow = 1, ncol = 2)
  result [1,1] = "Geodesic distance between two objects, meters"
  result [1,2] = DistanceBetweenTwoObjects
  
  return (result)
  
  
}

algorithm4_1 <- function(input, output)
{
  req (input)
  req (input$formula)
  req (output)
  
  switch (input$formula, 
          ALL = {
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            

            result <- algorithm4_1_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE)     
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          FORMULA_4_1_1 = {#Geodesic distance between two objects, meters
            
            #req (input$GeneralVariables.STCPlaceChangeCoeff)
            req (input$Coordinates.LonFirst)
            req (input$Coordinates.LatFirst)
            req (input$Coordinates.LonSecond)
            req (input$Coordinates.LatSecond)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- formula_4_1_1 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_4_1_2 = {#Distance connectivity matrix between investigated objects (localities) in estimated broadband network
            
            #req (input$GeneralVariables.STCPlaceChangeCoeff)

            req (input$Files.ListOfObjects)
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- formula_4_1_2 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
         stop ("No!")
          
  )
}
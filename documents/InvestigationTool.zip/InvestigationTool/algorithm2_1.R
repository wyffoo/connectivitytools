#Algorithm for overall FOCL construction cost evaluation

#Overall length of the FOCL construction site
formula_2_1_1 <- function (input, intermediate = NULL)
{
  req (input)
  
  result =  input$SchoolSpecificData.Length*1.01
  
  return (result)
}

#The average FOCL sections length requiring the construction of cable ducts
formula_2_1_2 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
    
  }
  
  result =  FOCLLenghtTotal*0.1
  
  return (result)
}

#The average FOCL sections length requiring cable-laying machine
formula_2_1_3 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
    
  }
  
  
  result =  FOCLLenghtTotal*0.9
  
  return (result)
}

#Number of cable manholes (CMh) 
formula_2_1_4 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
    
  }
  
  result =  round (FOCLLenghtTotal*2, digits = 0) + 1
  
  return (result)
}

#Number of cable couplings 
formula_2_1_5 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
    
  }
  
  result =  round (FOCLLenghtTotal*0.5, digits = 0) + 1
  
  return (result)
}

#Overall geodetic work along the object route
formula_2_1_6 <- function (input, intermediate = NULL)
{
  req (input)
  

  result =  input$SchoolSpecificData.Length * input$InitialDataFOCL.LaborCostNormGeo *
    input$InitialDataFOCL.CostNormGeo
  
  
  return (result)
}

#Total FOCL cost along route
formula_2_1_7 <- function (input, intermediate = NULL)
{
  req (input)
  
  result =  1.1*input$InitialDataFOCL.CostNormFOCLinst*input$SchoolSpecificData.Length
  
  return (result)
}

#Overall cost for FOCL sections construction of horizontal directional drilling, located at the crossings of roads
formula_2_1_8 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtHDD <- 0 
  FOCLLenghtHDD <- input$Intermediate.FOCLLenghtHDD
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtHDD <- as.numeric (intermediate$FOCLLenghtHDD)
    
  }
  
  result =  FOCLLenghtHDD*input$InitialDataFOCL.LaborCostNormHDD*input$InitialDataFOCL.CostNormHDD
  
  return (result)
}

#Overall cost for FOCL section construction requiring the cable duct 
formula_2_1_9 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLSectionLengthCD <- 0 
  FOCLSectionLengthCD <- input$Intermediate.FOCLSectionLengthCD
  
  
  if (!is.null(intermediate))
  {
    FOCLSectionLengthCD <- as.numeric (intermediate$FOCLSectionLengthCD)
    
  }
  
  result =  FOCLSectionLengthCD * (input$InitialDataFOCL.LaborCostNormCDC*
                                                       input$InitialDataFOCL.CostNormCDC + input$InitialDataFOCL.CostNormMaterialsCD)
  
  return (result)
}

#Overall cost for FOCL section construction requiring the cable laying machine 
formula_2_1_10 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLSectionLengthCLM <- 0 
  FOCLSectionLengthCLM <- input$Intermediate.FOCLSectionLengthCLM
  
  
  if (!is.null(intermediate))
  {
    FOCLSectionLengthCLM <- as.numeric (intermediate$FOCLSectionLengthCLM)
    
  }
  
  result =  FOCLSectionLengthCLM*
    input$InitialDataFOCL.LaborCostNormLC*input$InitialDataFOCL.CostNormLC
  
  
  return (result)
}

#Overall cost for cable manhole construction along the route
formula_2_1_11 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberCMh <- 0 
  NumberCMh <- input$Intermediate.NumberCMh
  
  
  if (!is.null(intermediate))
  {
    NumberCMh <- as.numeric (intermediate$NumberCMh)
    
  }
  
  result =  (input$InitialDataFOCL.CostNormMaterialsCMh + input$InitialDataFOCL.LaborCostNormCMh * 
               input$InitialDataFOCL.CostNormCMh)*NumberCMh
  
  
  return (result)
}

#Overall cost for cable coupling installation along the route
formula_2_1_12 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberCC <- 0 
  NumberCC <- input$Intermediate.NumberCC
  
  
  if (!is.null(intermediate))
  {
    NumberCC <- as.numeric (intermediate$NumberCC)
    
  }
  
  result =  (input$InitialDataFOCL.CostNormCC1km +
               input$InitialDataFOCL.LaborCostNormCCI*input$InitialDataFOCL.CostNormCCI)*NumberCC
  
  
  return (result)
}

#Overall cost for FOCL signaling test
formula_2_1_13 <- function (input, intermediate = NULL)
{
  req (input)
  
  FOCLLenghtTotal <- 0 
  FOCLLenghtTotal <- input$Intermediate.FOCLLenghtTotal
  
  
  if (!is.null(intermediate))
  {
    FOCLLenghtTotal <- as.numeric (intermediate$FOCLLenghtTotal)
    
  }
  
  result =  FOCLLenghtTotal*input$InitialDataFOCL.LaborCostNormST*input$InitialDataFOCL.CostNormST
  
  return (result)
}

#Total cost of technical specifications design
formula_2_1_14 <- function (input, intermediate = NULL)
{
  req (input)
  

  result =  input$InitialDataFOCL.LaborCostNormTS*input$InitialDataFOCL.CostNormTS
  
  return (result)
}

#Total cost of design solutions coordination
formula_2_1_15 <- function (input, intermediate = NULL)
{
  req (input)
  

  result =  input$InitialDataFOCL.LaborCostNormSC*input$InitialDataFOCL.CostNormSC
  
  return (result)
}

#Overall cost for ODF including organization of cable glands
formula_2_1_16 <- function (input, intermediate = NULL)
{
  req (input)
  
  
  result =  2*(input$InitialDataFOCL.CostMatCableGlands + input$InitialDataFOCL.LaborCostNormODF*
                 input$InitialDataFOCL.CostNormODFinst)
  
  return (result)
}

#Design cost
formula_2_1_17 <- function (input, intermediate = NULL)
{
  req (input)
  
  TotalFOCLcost <- 0 
  TotalFOCLcost <- input$Intermediate.TotalFOCLcost
  

  OverllCostFOCLSC <- 0 
  OverllCostFOCLSC <- input$Intermediate.OverllCostFOCLSC
  
  OverllCostFOCLCD <- 0 
  OverllCostFOCLCD <- input$Intermediate.OverllCostFOCLCD
  
  OverllCostFOCLCLM <- 0 
  OverllCostFOCLCLM <- input$Intermediate.OverllCostFOCLCLM

  OverllCostODF <- 0 
  OverllCostODF <- input$Intermediate.OverllCostODF
  
  OverllCostFOCLCMh <- 0 
  OverllCostFOCLCMh <- input$Intermediate.OverllCostFOCLCMh
  
  OverllCostFOCLCC <- 0 
  OverllCostFOCLCC <- input$Intermediate.OverllCostFOCLCC
  
    
  if (!is.null(intermediate))
  {
    TotalFOCLcost <- as.numeric (intermediate$TotalFOCLcost)
    
    OverllCostFOCLSC <- as.numeric (intermediate$OverllCostFOCLSC)
    OverllCostFOCLCD <- as.numeric (intermediate$OverllCostFOCLCD)
    OverllCostFOCLCLM <- as.numeric (intermediate$OverllCostFOCLCLM)
    OverllCostODF <- as.numeric (intermediate$OverllCostODF)
    OverllCostFOCLCMh <- as.numeric (intermediate$OverllCostFOCLCMh)
    OverllCostFOCLCC <- as.numeric (intermediate$OverllCostFOCLCC)
  }
  
  result =  (TotalFOCLcost+
               OverllCostFOCLSC+
               OverllCostFOCLCD + 
               OverllCostFOCLCLM + 
               OverllCostODF + 
               OverllCostFOCLCMh + 
               OverllCostFOCLCC)*0.05
  
  
  return (result)
}

#Overall cost of FOCL installation
formula_2_1_18 <- function (input, intermediate = NULL)
{
  req (input)
  
  OverllCostFOCLGeo <- 0 
  OverllCostFOCLGeo <- input$Intermediate.OverllCostFOCLGeo
  
  TotalFOCLcost <- 0 
  TotalFOCLcost <- input$Intermediate.TotalFOCLcost
  
  OverllCostFOCLSC <- 0 
  OverllCostFOCLSC <- input$Intermediate.OverllCostFOCLSC
  
  OverllCostFOCLCD <- 0 
  OverllCostFOCLCD <- input$Intermediate.OverllCostFOCLCD
  
  OverllCostFOCLCLM <- 0 
  OverllCostFOCLCLM <- input$Intermediate.OverllCostFOCLCLM
  
  OverllCostODF <- 0 
  OverllCostODF <- input$Intermediate.OverllCostODF
  
  OverllCostFOCLCMh <- 0 
  OverllCostFOCLCMh <- input$Intermediate.OverllCostFOCLCMh
  
  OverllCostFOCLCC <- 0 
  OverllCostFOCLCC <- input$Intermediate.OverllCostFOCLCC
  
  OverllCostFOCLTS <- 0 
  OverllCostFOCLTS <- input$Intermediate.OverllCostFOCLTS
  
  OverllCostFOCLSC <- 0 
  OverllCostFOCLSC <- input$Intermediate.OverllCostFOCLSC
  
  OverllCostFOCLST <- 0 
  OverllCostFOCLST <- input$Intermediate.OverllCostFOCLST
  
  OverllCostFOCLDesign <- 0 
  OverllCostFOCLDesign <- input$Intermediate.OverllCostFOCLDesign
  
  
    
  if (!is.null(intermediate))
  {
    OverllCostFOCLGeo <- as.numeric (intermediate$OverllCostFOCLGeo)
    TotalFOCLcost <- as.numeric (intermediate$TotalFOCLcost)
    OverllCostFOCLSC <- as.numeric (intermediate$OverllCostFOCLSC)
    OverllCostFOCLCD <- as.numeric (intermediate$OverllCostFOCLCD)
    OverllCostFOCLCLM <- as.numeric (intermediate$OverllCostFOCLCLM)
    OverllCostODF <- as.numeric (intermediate$OverllCostODF)
    OverllCostFOCLCMh <- as.numeric (intermediate$OverllCostFOCLCMh)
    OverllCostFOCLCC <- as.numeric (intermediate$OverllCostFOCLCC)
    OverllCostFOCLTS <- as.numeric (intermediate$OverllCostFOCLTS)
    OverllCostFOCLSC <- as.numeric (intermediate$OverllCostFOCLSC)
    OverllCostFOCLST <- as.numeric (intermediate$OverllCostFOCLST)
    OverllCostFOCLDesign <- as.numeric (intermediate$OverllCostFOCLDesign)
    
  }
  
  result =  OverllCostFOCLGeo +
    TotalFOCLcost + 
    OverllCostFOCLSC  + 
    OverllCostFOCLCD  + 
    OverllCostFOCLCLM  + 
    OverllCostODF   +
    OverllCostFOCLCMh  + 
    OverllCostFOCLCC  + 
    OverllCostFOCLTS  + 
    OverllCostFOCLST  + 
    OverllCostFOCLDesign
  
  
  return (result)
}

#Сost of equipment and materials for the construction of fiber optic lines
formula_2_1_19 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberCC <- 0 
  NumberCC <- input$Intermediate.NumberCC
  
  NumberCMh <- 0 
  NumberCMh <- input$Intermediate.NumberCMh
  
  FOCLSectionLengthCLM <- 0 
  FOCLSectionLengthCLM <- input$Intermediate.FOCLSectionLengthCLM
  
  TotalFOCLcost <- 0 
  TotalFOCLcost <- input$Intermediate.TotalFOCLcost
  
  
  if (!is.null(intermediate))
  {
    NumberCC <- as.numeric (intermediate$NumberCC)
    
    NumberCMh <- as.numeric (intermediate$NumberCMh)
    FOCLSectionLengthCLM <- as.numeric (intermediate$FOCLSectionLengthCLM)
    TotalFOCLcost <- as.numeric (intermediate$TotalFOCLcost)

  }
  
  result =  input$InitialDataFOCL.CostNormCC1km*NumberCC + 
    input$InitialDataFOCL.CostNormMaterialsCMh*NumberCMh + 
    input$InitialDataFOCL.CostNormMaterialsCD*FOCLSectionLengthCLM + 
    TotalFOCLcost + 2*input$InitialDataFOCL.CostMatCableGlands
  
    
  return (result)
}


algorithm2_1_impl <- function(input, intermediate = NULL)
{

  #Overall length of the FOCL construction site
  
  FOCLLenghtTotal =  formula_2_1_1 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall length of the FOCL construction site, km", FOCLLenghtTotal, sep = ": "))  
  
  #The average FOCL sections length requiring the construction of cable ducts
  intermediate2 <- list (FOCLLenghtTotal = 0.0)
  intermediate2$FOCLLenghtTotal <- FOCLLenghtTotal
  
  FOCLSectionLengthCD =  formula_2_1_2 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("The average FOCL sections length requiring the construction of cable ducts, km", FOCLSectionLengthCD, sep = ": "))  
  
  #The average FOCL sections length requiring cable-laying machine
  
  FOCLSectionLengthCLM =  formula_2_1_3 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("The average FOCL sections length requiring cable-laying machine, km", FOCLSectionLengthCLM, sep = ": "))  
  
  #Number of cable manholes (CMh) 
  
  NumberCMh =  formula_2_1_4 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Number of cable manholes (CMh), units", NumberCMh, sep = ": "))  
  
  #Number of cable couplings 
  
  NumberCC =  formula_2_1_5 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Number of cable couplings, units", NumberCC, sep = ": "))  
  
  #Overall geodetic work along the object route
  
  OverllCostFOCLGeo =  formula_2_1_6 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall geodetic work cost along the object route, currency units", OverllCostFOCLGeo, sep = ": "))  
  
  #Total FOCL cost along route
  
  TotalFOCLcost =  formula_2_1_7 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total FOCL cost along route, currency units", TotalFOCLcost, sep = ": "))  
  
  #Overall cost for FOCL sections construction of horizontal directional drilling, located at the crossings of roads            
  
  OverllCostFOCLSC =  formula_2_1_8 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for FOCL sections construction of horizontal directional drilling, located at the crossings of roads, currency units", OverllCostFOCLSC, sep = ": "))  
  
  #Overall cost for FOCL section construction requiring the cable duct 
  intermediate3 <- list (FOCLSectionLengthCD = 0.0, FOCLSectionLengthCLM = 0.0, NumberCMh = 0, NumberCC = 0)
  intermediate3$FOCLSectionLengthCD <- FOCLSectionLengthCD
  intermediate3$FOCLSectionLengthCLM <- FOCLSectionLengthCLM
  intermediate3$NumberCMh <- NumberCMh
  intermediate3$NumberCC <- NumberCC
  
  OverllCostFOCLCD =  formula_2_1_9 (input, intermediate3)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for FOCL section construction requiring the cable duct, currency units", OverllCostFOCLCD, sep = ": "))  
  
  
  #Overall cost for FOCL section construction requiring the cable laying machine             
  
  OverllCostFOCLCLM =  formula_2_1_10 (input, intermediate3)
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for FOCL section construction requiring the cable laying machine, currency units", OverllCostFOCLCLM, sep = ": "))  
  
  
  #Overall cost for cable manhole construction along the route
  
  OverllCostFOCLCMh =  formula_2_1_11 (input, intermediate3)
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for cable manhole construction along the route, currency units", OverllCostFOCLCMh, sep = ": "))  
  
  
  #Overall cost for cable coupling installation along the route
  
  OverllCostFOCLCC =  formula_2_1_12 (input, intermediate3)
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for cable coupling installation along the route, currency units", OverllCostFOCLCC, sep = ": "))  
  
  #Overall cost for FOCL signaling test
  
  OverllCostFOCLST =  formula_2_1_13 (input, intermediate2)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for FOCL signaling test, currency units", OverllCostFOCLST, sep = ": "))  
  
  #Total cost of technical specifications design
  
  OverllCostFOCLTS =  formula_2_1_14 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost of technical specifications design, currency units", OverllCostFOCLTS, sep = ": "))  
  
  #Total cost of design solutions coordination            
  
  OverllCostFOCLSC =  formula_2_1_15 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost of design solutions coordination, currency unists", OverllCostFOCLSC, sep = ": "))  

  #Overall cost for ODF including organization of cable glands
  OverllCostODF = formula_2_1_16 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Overall cost for ODF including organization of cable glands, currency unists", OverllCostODF, sep = ": "))  
    
  #Design cost
  intermediate4 <- list (TotalFOCLcost = 0.0, 
                           OverllCostFOCLSC = 0.0, 
                           OverllCostFOCLCD = 0.0, 
                           OverllCostFOCLCLM  = 0.0, 
                         OverllCostODF  = 0.0,
                           OverllCostFOCLCMh = 0.0, 
                           OverllCostFOCLCC  = 0.0,
                         OverllCostFOCLDesign = 0.0,
                         OverllCostFOCLGeo = 0.0,
                         OverllCostFOCLTS = 0.0,
                         OverllCostFOCLST = 0.0)  
  
  intermediate4$TotalFOCLcost <- TotalFOCLcost
  intermediate4$OverllCostFOCLSC <- OverllCostFOCLSC
  intermediate4$OverllCostFOCLCD <- OverllCostFOCLCD
  intermediate4$OverllCostFOCLCLM <- OverllCostFOCLCLM
  intermediate4$OverllCostODF <- OverllCostODF
  intermediate4$OverllCostFOCLCMh <- OverllCostFOCLCMh
  intermediate4$OverllCostFOCLCC  <- OverllCostFOCLCC
  intermediate4$OverllCostFOCLGeo  <- OverllCostFOCLGeo
  intermediate4$OverllCostFOCLTS  <- OverllCostFOCLTS
  intermediate4$OverllCostFOCLST  <- OverllCostFOCLST
  
  OverllCostFOCLDesign =  formula_2_1_17 (input, intermediate4)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Design cost, currency units", OverllCostFOCLDesign, sep = ": "))  
  
  #Overall cost of FOCL installation  
  
  intermediate4$OverllCostFOCLDesign  <- OverllCostFOCLDesign
  
  #print (.GlobalEnv$mylog)
  
  result <- matrix (nrow = 4, ncol = 2)
  result [1,1] = "Overall cost of FOCL installation, currency units"
  result [1,2] = formula_2_1_18 (input, intermediate4)
  
  
  result [2,1] = "Overall length of the FOCL construction site, km"
  result [2,2] = FOCLLenghtTotal 
  
  result [3,1] = "The average FOCL sections length requiring the construction of cable ducts, km"
  result [3,2] = FOCLSectionLengthCD 
  


  intermediate5 <- list (NumberCC = 0.0, 
                         NumberCMh = 0.0, 
                         FOCLSectionLengthCLM = 0.0, 
                         TotalFOCLcost  = 0.0)  

  intermediate5$TotalFOCLcost <- TotalFOCLcost
  intermediate5$NumberCC <- NumberCC
  intermediate5$NumberCMh <- NumberCMh
  intermediate5$FOCLSectionLengthCLM <- FOCLSectionLengthCLM
  
    
  result [4,1] = "Сost of equipment and materials for the construction of fiber optic lines, currency units"
  result [4,2] = formula_2_1_19 (input, intermediate5)
  
  return (result)
}
  


algorithm2_1 <- function(input, output)
{
  req (input)
  req (input$formula)
  req (output)
  
  switch (input$formula, 
          ALL = {
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataFOCL.LaborCostNormGeo)
            req (input$InitialDataFOCL.CostNormGeo)
            req (input$InitialDataFOCL.CostNormFOCLinst)
            req (input$InitialDataFOCL.LaborCostNormHDD)
            req (input$InitialDataFOCL.CostNormHDD)
            req (input$InitialDataFOCL.LaborCostNormCDC)
            req (input$InitialDataFOCL.CostNormCDC)
            req (input$InitialDataFOCL.CostNormMaterialsCD)
            req (input$InitialDataFOCL.LaborCostNormLC)
            req (input$InitialDataFOCL.CostNormLC)
            req (input$InitialDataFOCL.CostNormMaterialsCMh)
            req (input$InitialDataFOCL.LaborCostNormCMh)
            req (input$InitialDataFOCL.CostNormCMh)
            req (input$InitialDataFOCL.CostNormCC1km)
            req (input$InitialDataFOCL.LaborCostNormCCI)
            req (input$InitialDataFOCL.CostNormCCI)
            req (input$InitialDataFOCL.LaborCostNormST)
            req (input$InitialDataFOCL.CostNormST)
            req (input$InitialDataFOCL.LaborCostNormTS)
            req (input$InitialDataFOCL.CostNormTS)
            req (input$InitialDataFOCL.LaborCostNormSC)
            req (input$InitialDataFOCL.CostNormSC)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            

            result <- algorithm2_1_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE)     
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          FORMULA_2_1_1 = {#Overall length of the FOCL construction site
            req (input$SchoolSpecificData.Length)
            
            result <- formula_2_1_1 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_1_2 = {#The average FOCL sections length requiring the construction of cable ducts
            req (input$Intermediate.FOCLLenghtTotal)
            
            result <- formula_2_1_2 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_3 = {#The average FOCL sections length requiring cable-laying machine
            req (input$Intermediate.FOCLLenghtTotal)
            
            result <- formula_2_1_3 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_4 = {#Number of cable manholes (CMh) 
            req (input$Intermediate.FOCLLenghtTotal)
            
            result <- formula_2_1_4 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_5 = {#Number of cable couplings 
            req (input$Intermediate.FOCLLenghtTotal)
            
            result <- formula_2_1_5 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_6 = {#Overall geodetic work along the object route
            
            req (input$SchoolSpecificData.Length)
            req (input$InitialDataFOCL.LaborCostNormGeo)
            req (input$InitialDataFOCL.CostNormGeo)
            
            
            result <- formula_2_1_6 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_7 = {#Total FOCL cost along route
            
            req (input$InitialDataFOCL.CostNormFOCLinst)
            req (input$SchoolSpecificData.Length)
            
            result <- formula_2_1_7 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_8 = {#Overall cost for FOCL sections construction of horizontal directional drilling, located at the crossings of roads
            req (input$InitialDataFOCL.LaborCostNormHDD)
            req (input$InitialDataFOCL.CostNormHDD)
            req (input$Intermediate.FOCLLenghtHDD)
            
            
            result <- formula_2_1_8 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_9 = {#Overall cost for FOCL section construction requiring the cable duct 
            req (input$Intermediate.FOCLSectionLengthCD)
            req (input$InitialDataFOCL.LaborCostNormCDC)
            req (input$InitialDataFOCL.CostNormCDC)
            req (input$InitialDataFOCL.CostNormMaterialsCD)
            
            
            result <- formula_2_1_9 (input)            
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_10 = {#Overall cost for FOCL section construction requiring the cable laying machine 
            req (input$Intermediate.FOCLSectionLengthCLM)
            req (input$InitialDataFOCL.LaborCostNormLC)
            req (input$InitialDataFOCL.CostNormLC)
            
            result <- formula_2_1_10 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_11 = {#Overall cost for cable manhole construction along the route
            req (input$InitialDataFOCL.CostNormMaterialsCMh)
            req (input$InitialDataFOCL.LaborCostNormCMh)
            req (input$InitialDataFOCL.CostNormCMh)
            req (input$Intermediate.NumberCMh)
            
            result <- formula_2_1_11 (input)            
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_12 = {#Overall cost for cable coupling installation along the route
            req (input$InitialDataFOCL.CostNormCC1km)
            req (input$InitialDataFOCL.LaborCostNormCCI)
            req (input$InitialDataFOCL.CostNormCCI)
            req (input$Intermediate.NumberCC)
            
            result <- formula_2_1_12 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_13 = {#Overall cost for FOCL signaling test
            req (input$Intermediate.FOCLLenghtTotal)
            req (input$InitialDataFOCL.LaborCostNormST)
            req (input$InitialDataFOCL.CostNormST)
            
            result <- formula_2_1_13 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_14 = {#Total cost of technical specifications design
            req (input$InitialDataFOCL.LaborCostNormTS)
            req (input$InitialDataFOCL.CostNormTS)
            
            result <- formula_2_1_14 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_15 = {#Total cost of design solutions coordination
            req (input$InitialDataFOCL.LaborCostNormSC)
            req (input$InitialDataFOCL.CostNormSC)
            
            result <- formula_2_1_15 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_16 = {#Overall cost for ODF including organization of cable glands
            req (input$InitialDataFOCL.CostMatCableGlands)
            req (input$InitialDataFOCL.LaborCostNormODF)
            req (input$InitialDataFOCL.CostNormODFinst)
            
            
            result <- formula_2_1_16 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_17 = {#Design cost
            req (input$Intermediate.TotalFOCLcost)
            req (input$Intermediate.OverllCostFOCLSC)
            req (input$Intermediate.OverllCostFOCLCD)
            req (input$Intermediate.OverllCostFOCLCLM)
            req (input$Intermediate.OverllCostODF)
            req (input$Intermediate.OverllCostFOCLCMh)
            req (input$Intermediate.OverllCostFOCLCC)
            
            result <- formula_2_1_17 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_18 = {#Overall cost of FOCL installation
            req (input$Intermediate.OverllCostFOCLGeo)
            req (input$Intermediate.TotalFOCLcost)
            req (input$Intermediate.OverllCostFOCLSC)
            req (input$Intermediate.OverllCostFOCLCD)
            req (input$Intermediate.OverllCostFOCLCLM)
            req (input$Intermediate.OverllCostODF)
            req (input$Intermediate.OverllCostFOCLCMh)
            req (input$Intermediate.OverllCostFOCLCC)
            req (input$Intermediate.OverllCostFOCLTS)
            req (input$Intermediate.OverllCostFOCLSC)
            req (input$Intermediate.OverllCostFOCLST)
            req (input$Intermediate.OverllCostFOCLDesign)
            
            result <- formula_2_1_18 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          FORMULA_2_1_19 = {#Сost of equipment and materials for the construction of fiber optic lines
            req (input$InitialDataFOCL.CostNormCC1km)
            req (input$Intermediate.NumberCC)
            req (input$InitialDataFOCL.CostNormMaterialsCMh)
            req (input$Intermediate.NumberCMh)
            req (input$InitialDataFOCL.CostNormMaterialsCD)
            req (input$Intermediate.FOCLSectionLengthCLM)
            req (input$Intermediate.TotalFOCLcost)
            req (input$InitialDataFOCL.CostMatCableGlands)
            
            
            result <- formula_2_1_19 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
            
          },
          stop ("No!")
          
        )
}
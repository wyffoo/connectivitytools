#Algorithm for total RTS maintenance cost evaluation between object and SN in locality

#Total cost for all RTS pylon maintenance
formula_2_4_1 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.AnnualLaborPylon*input$InitialDataRadio.CostLaborPylonm*
    (NumberOfRepeaters+input$InitialDataRadio.NumberOfTerminals)
  
  
  return (result)
}

#Total cost for all RTS antenna feeder devices maintenance
formula_2_4_2 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.AnnualLaborAFD*input$InitialDataRadio.CostLaborAFDm*(NumberOfRepeaters+input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Total cost for RTS internal devices maintenance
formula_2_4_3 <- function (input, intermediate = NULL)
{
  req (input)
  
  NumberOfRepeaters <- 0 
  NumberOfRepeaters <- input$Intermediate.NumberOfRepeaters
  
  
  if (!is.null(intermediate))
  {
    NumberOfRepeaters <- as.numeric (intermediate$NumberOfRepeaters)
  }
  
  result =  input$InitialDataRadio.AnnualLaborRTS*input$InitialDataRadio.CostLaborRTSm*(NumberOfRepeaters+input$InitialDataRadio.NumberOfTerminals)
  
  return (result)
}

#Total cost of RTS maintenance
formula_2_4_4 <- function (input, intermediate = NULL)
{
  req (input)
  
  TotalCostAllRTSm <- 0 
  TotalCostAllRTSm <- input$Intermediate.TotalCostAllRTSm
  
  TotalCostAllAFDm <- 0 
  TotalCostAllAFDm <- input$Intermediate.TotalCostAllAFDm
  
  TotalCostAllInternalDm <- 0 
  TotalCostAllInternalDm <- input$Intermediate.TotalCostAllInternalDm
  
    
  if (!is.null(intermediate))
  {
    TotalCostAllRTSm <- as.numeric (intermediate$TotalCostAllRTSm)
    TotalCostAllAFDm <- as.numeric (intermediate$TotalCostAllAFDm)
    TotalCostAllInternalDm <- as.numeric (intermediate$TotalCostAllInternalDm)
  }
  
  result =  TotalCostAllRTSm+TotalCostAllAFDm+TotalCostAllInternalDm
  
  return (result)
}


algorithm2_4_impl <- function(input, intermediate = NULL)
{
  #Total cost for all RTS pylon maintenance
  TotalCostAllRTSm =  formula_2_4_1 (input, intermediate)
  
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for all RTS pylon maintenance, currency units/year", TotalCostAllRTSm, sep = ": "))  
  
  #Total cost for all RTS antenna feeder devices maintenance
  TotalCostAllAFDm =  formula_2_4_2 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for all RTS antenna feeder devices maintenance, currency units/year", TotalCostAllAFDm, sep = ": "))  
  
  #Total cost for RTS internal devices maintenance
  TotalCostAllInternalDm =  formula_2_4_3 (input, intermediate)
  .GlobalEnv$mylog <- append(.GlobalEnv$mylog, paste ("Total cost for RTS internal devices maintenance, currency units/year", TotalCostAllInternalDm, sep = ": "))  
  
  #Total cost of RTS maintenance
  
  intermediate2 <- list (TotalCostAllRTSm = 0.0, TotalCostAllAFDm = 0.0, TotalCostAllInternalDm = 0.0)
  intermediate2$TotalCostAllRTSm <- TotalCostAllRTSm
  intermediate2$TotalCostAllAFDm <- TotalCostAllAFDm
  intermediate2$TotalCostAllInternalDm  <- TotalCostAllInternalDm            
  
  result <- matrix (nrow = 1, ncol = 2)
  result [1,1] = "Annual cost of RTS maintenance, currency units/year"
  result [1,2] = formula_2_4_4 (input, intermediate2)
  
  return (result)
}

algorithm2_4 <- function(input, output)
{
  req (input)
  req (input$formula)
  req (output)
  
  switch (input$formula, 
          ALL = {
            
            req (input$InitialDataRadio.AnnualLaborPylon)
            req (input$InitialDataRadio.CostLaborPylonm)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            req (input$InitialDataRadio.AnnualLaborAFD)
            req (input$InitialDataRadio.CostLaborAFDm)
            req (input$InitialDataRadio.AnnualLaborRTS)
            req (input$InitialDataRadio.CostLaborRTSm)
            
            .GlobalEnv$mylog <- matrix("Detailed Calculation Log:")
            
            result <- algorithm2_4_impl (input)
            
            output$c_names <- NULL
            output$data <- renderTable(result, colnames=FALSE)       
            
            output$log <- renderTable(.GlobalEnv$mylog, colnames = FALSE)
            
          },
          FORMULA_2_4_1 = {#Total cost for all RTS pylon maintenance
            
            req (input$InitialDataRadio.AnnualLaborPylon)
            req (input$InitialDataRadio.CostLaborPylonm)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            
            result <- formula_2_4_1 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_4_2 = {#Total cost for all RTS antenna feeder devices maintenance
            
            req (input$InitialDataRadio.AnnualLaborAFD)
            req (input$InitialDataRadio.CostLaborAFDm)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            result <- formula_2_4_2 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_4_3 = {#Total cost for RTS internal devices maintenance
            req (input$InitialDataRadio.AnnualLaborRTS)
            req (input$InitialDataRadio.CostLaborRTSm)
            req (input$Intermediate.NumberOfRepeaters)
            req (input$InitialDataRadio.NumberOfTerminals)
            
            result <- formula_2_4_3 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          FORMULA_2_4_4 = {#Total cost of RTS maintenance
            req (input$Intermediate.TotalCostAllRTSm)
            req (input$Intermediate.TotalCostAllAFDm)
            req (input$Intermediate.TotalCostAllInternalDm)
            
            result <- formula_2_4_4 (input)
            
            output$data <- renderTable(result, colnames=FALSE)
          },
          stop ("No!")
          
  )
}